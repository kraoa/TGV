 function y = rect(x)
%function y = rect(x)
% unit-width rect function
y = double6(abs(x) < 0.5);
