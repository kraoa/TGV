 function r = deg2rad(d)
%function r = deg2rad(d)
% Convert from degrees to radians.

r=d*pi/180;
