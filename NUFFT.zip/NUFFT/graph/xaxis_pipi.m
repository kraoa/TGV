 function xaxis_pipi
%function xaxis_pipi
% label xaxis from -pi to pi

warning 'xaxis_pipi is obsolete.  use xaxis_pi'
xaxis_pi '-p -p/2 0 p/2 p'
