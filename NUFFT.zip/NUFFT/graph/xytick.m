 function xytick(x, y)
%| set axis xticks and yticks with one function call
%| because function handles cannot do two things
xtick(x)
ytick(y)
